package com.sunbeam;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the array of floating-point values separated by spaces:");
        String[] inputValues = scanner.nextLine().split(" ");
        double[] values = new double[inputValues.length];
        for (int i = 0; i < inputValues.length; i++) {
            values[i] = Double.parseDouble(inputValues[i]);
        }

        BSTOperations bst = new BSTOperations();
        bst.constructBST(values);

        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Search for a node");
            System.out.println("2. Preorder Recursive Traversal");
            System.out.println("3. Find nth Smallest Element");
            System.out.println("4. Check if the first node is an ancestor of the second node");
            System.out.println("5. Find smallest and highest element at HEIGHT");
            System.out.println("6. Count number of descendants for a given node");
            System.out.println("0. Exit");

            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter the node to search: ");
                    double searchKey = scanner.nextDouble();
                    System.out.println("Node " + (bst.search(searchKey) ? "found" : "not found") + " in the tree.");
                    break;
                case 2:
                    System.out.println("Preorder Recursive Traversal:");
                    bst.preorderRecursive(bst.root);
                    System.out.println();
                    break;
                case 3:
                    System.out.print("Enter the value of n: ");
                    int n = scanner.nextInt();
                    double nthSmallest = bst.findNthSmallest(n);
                    if (nthSmallest != -1) {
                        System.out.println("The " + n + "th smallest element is: " + nthSmallest);
                    } else {
                        System.out.println("Invalid value of n.");
                    }
                    break;
                case 4:
                    System.out.print("Enter the first node: ");
                    double ancestor = scanner.nextDouble();
                    System.out.print("Enter the second node: ");
                    double descendant = scanner.nextDouble();
                    System.out.println("Node " + (bst.isAncestor(ancestor, descendant) ? "is" : "is not") + " an ancestor of the second node.");
                    break;
                case 5 :
                	break;
                case 6:
                    System.out.print("Enter the node to count descendants: ");
                    double nodeToCount = scanner.nextDouble();
                    int descendantCount = bst.countDescendants(nodeToCount);
                    System.out.println("Number of descendants for node " + nodeToCount + ": " + descendantCount);
                    break;
                case 0:
                    System.out.println("Exiting program.");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
    }
}

