package com.sunbeam;

	import java.util.Scanner;

	class Node {
	    double data;
	    Node left, right;

	    public Node(double item) {
	        data = item;
	        left = right = null;
	    }
	}

	public class BSTOperations {
	    Node root;

	    // Constructor
	    public BSTOperations() {
	        root = null;
	    }

	    // Insert a new node into the BST
	    private Node insert(Node root, double data) {
	        if (root == null) {
	            root = new Node(data);
	            return root;
	        }

	        if (data < root.data) {
	            root.left = insert(root.left, data);
	        } else if (data > root.data) {
	            root.right = insert(root.right, data);
	        }

	        return root;
	    }

	    // Function to construct the BST from an array
	    void constructBST(double[] values) {
	        for (double value : values) {
	            root = insert(root, value);
	        }
	    }

	    // Search for a node using DFS algorithm
	    boolean search(double key) {
	        return searchDFS(root, key);
	    }

	    private boolean searchDFS(Node root, double key) {
	        if (root == null) {
	            return false;
	        }

	        if (root.data == key) {
	            return true;
	        }

	        return searchDFS(root.left, key) || searchDFS(root.right, key);
	    }

	    // Preorder traversal (recursive)
	    void preorderRecursive(Node root) {
	        if (root != null) {
	            System.out.print(root.data + " ");
	            preorderRecursive(root.left);
	            preorderRecursive(root.right);
	        }
	    }

	    // Find the nth smallest element in the BST
	    double findNthSmallest(int n) {
	        int[] count = { 0 };
	        return findNthSmallestUtil(root, n, count);
	    }

	    private double findNthSmallestUtil(Node root, int n, int[] count) {
	        if (root == null) {
	            return -1; // Invalid value for not found
	        }

	        double left = findNthSmallestUtil(root.left, n, count);

	        if (left != -1) {
	            return left;
	        }

	        count[0]++;
	        if (count[0] == n) {
	            return root.data;
	        }

	        return findNthSmallestUtil(root.right, n, count);
	    }

	    // Check if the first node is an ancestor of the second
	    boolean isAncestor(double ancestor, double descendant) {
	        return isAncestorUtil(root, ancestor, descendant);
	    }

	    private boolean isAncestorUtil(Node root, double ancestor, double descendant) {
	        if (root == null) {
	            return false;
	        }

	        if (root.data == ancestor) {
	            return searchDFS(root, descendant);
	        }

	        return isAncestorUtil(root.left, ancestor, descendant) || isAncestorUtil(root.right, ancestor, descendant);
	    }


	    // Count the number of descendants for a given node
	    int countDescendants(double key) {
	        return countDescendantsUtil(root, key) - 1; // Exclude the node itself
	    }

	    private int countDescendantsUtil(Node root, double key) {
	        if (root == null) {
	            return 0;
	        }

	        if (root.data == key) {
	            return 1 + size(root.left) + size(root.right);
	        }

	        if (key < root.data) {
	            return countDescendantsUtil(root.left, key);
	        } else {
	            return countDescendantsUtil(root.right, key);
	        }
	    }

	    // Helper function to get the size of the subtree rooted at the given node
	    private int size(Node node) {
	        if (node == null) {
	            return 0;
	        }
	        return 1 + size(node.left) + size(node.right);
	    }
}
